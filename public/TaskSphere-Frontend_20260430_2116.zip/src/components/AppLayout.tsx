"use client";

import Navbar from "./Navbar";
import { useAuth } from "@/context/AuthContext";

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const { auth } = useAuth();

  if (!auth?.isAuthenticated) {
    return <>{children}</>;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navbar />
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 py-6">{children}</main>
      <footer className="border-t bg-card mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between text-sm text-muted-foreground">
          <span className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-primary flex items-center justify-center">
              <span className="text-primary-foreground text-[8px] font-bold">TS</span>
            </div>
            TaskSphere &copy; {new Date().getFullYear()}
          </span>
          <span className="hidden sm:inline">Task Management Platform</span>
        </div>
      </footer>
    </div>
  );
}
