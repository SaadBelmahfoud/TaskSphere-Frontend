import { useQuery } from "@tanstack/react-query";
import api from "@/lib/api";
import type { UserAdminResponse } from "@/types";

/**
 * Fetch the list of users for assignee selection.
 * Uses the admin users endpoint (ADMIN and MANAGER should have access).
 * Falls back gracefully if access is denied.
 */
export function useUsers() {
  return useQuery<UserAdminResponse[]>({
    queryKey: ["users"],
    queryFn: async () => {
      try {
        const res = await api.get("/iam/admin/users");
        return res.data;
      } catch {
        // If endpoint is not accessible, return empty array
        return [];
      }
    },
    staleTime: 1000 * 60 * 5, // 5 minutes cache
  });
}
