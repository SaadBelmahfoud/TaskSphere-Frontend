'use client';

import AppLayout from '@/components/AppLayout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  ClipboardList,
  CalendarPlus,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Activity,
} from 'lucide-react';
import { useDashboardStatsQuery } from '@/hooks/useDashboard';

const statusLabels: Record<string, string> = {
  TODO: 'À faire',
  DOING: 'En cours',
  DONE: 'Terminé',
};

const statusColors: Record<string, string> = {
  TODO: 'bg-slate-400',
  DOING: 'bg-amber-400',
  DONE: 'bg-emerald-400',
};

const priorityLabels: Record<string, string> = {
  LOW: 'Basse',
  MEDIUM: 'Moyenne',
  HIGH: 'Haute',
  CRITICAL: 'Critique',
};

const priorityColors: Record<string, string> = {
  LOW: 'bg-slate-400',
  MEDIUM: 'bg-yellow-400',
  HIGH: 'bg-orange-400',
  CRITICAL: 'bg-red-500',
};

const actionLabels: Record<string, string> = {
  TASK_CREATED: 'Création',
  TASK_UPDATED: 'Modification',
  TASK_STATUS_CHANGED: 'Changement de statut',
  TASK_ASSIGNED: 'Assignation',
  TASK_UNASSIGNED: 'Désassignation',
  TASK_DELETED: 'Suppression',
  COMMENT_ADDED: 'Commentaire',
  COMMENT_UPDATED: 'Commentaire modifié',
  COMMENT_DELETED: 'Commentaire supprimé',
  USER_ROLE_CHANGED: 'Changement de rôle',
  USER_TOGGLED: 'Activation/Désactivation',
};

const actionColors: Record<string, string> = {
  TASK_CREATED: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  TASK_UPDATED: 'bg-blue-100 text-blue-700 border-blue-200',
  TASK_STATUS_CHANGED: 'bg-amber-100 text-amber-700 border-amber-200',
  TASK_ASSIGNED: 'bg-purple-100 text-purple-700 border-purple-200',
  TASK_UNASSIGNED: 'bg-gray-100 text-gray-700 border-gray-200',
  TASK_DELETED: 'bg-red-100 text-red-700 border-red-200',
  COMMENT_ADDED: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  COMMENT_UPDATED: 'bg-cyan-100 text-cyan-700 border-cyan-200',
  COMMENT_DELETED: 'bg-red-100 text-red-700 border-red-200',
  USER_ROLE_CHANGED: 'bg-orange-100 text-orange-700 border-orange-200',
  USER_TOGGLED: 'bg-orange-100 text-orange-700 border-orange-200',
};

function formatRelativeTime(timestamp: string) {
  const now = new Date();
  const date = new Date(timestamp);
  const diffMs = now.getTime() - date.getTime();
  const diffSeconds = Math.floor(diffMs / 1000);
  const diffMinutes = Math.floor(diffSeconds / 60);
  const diffHours = Math.floor(diffMinutes / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSeconds < 60) return "À l'instant";
  if (diffMinutes < 60) return `Il y a ${diffMinutes} min`;
  if (diffHours < 24) return `Il y a ${diffHours}h`;
  if (diffDays < 7) return `Il y a ${diffDays}j`;
  return date.toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatTimestamp(timestamp: string) {
  return new Date(timestamp).toLocaleDateString('fr-FR', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export default function DashboardPage() {
  const { data: stats, isLoading, isError } = useDashboardStatsQuery();

  const statCards = stats
    ? [
        {
          label: 'Total des tâches',
          value: stats.totalTasks,
          icon: ClipboardList,
          color: 'text-primary',
        },
        {
          label: 'Créées cette semaine',
          value: stats.tasksCreatedThisWeek,
          icon: CalendarPlus,
          color: 'text-emerald-600',
        },
        {
          label: 'Terminées cette semaine',
          value: stats.tasksCompletedThisWeek,
          icon: CheckCircle2,
          color: 'text-emerald-500',
        },
        {
          label: 'En retard',
          value: stats.overdueTasks,
          icon: AlertTriangle,
          color: 'text-red-500',
        },
      ]
    : [];

  return (
    <AppLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Tableau de bord</h1>
          <p className="text-muted-foreground text-sm mt-1">
            Vue d&apos;ensemble de vos tâches et activités récentes
          </p>
        </div>

        {/* Cartes statistiques */}
        {isLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Card key={i}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-5 w-5 rounded" />
                    <Skeleton className="h-8 w-10" />
                  </div>
                  <Skeleton className="h-4 w-28 mt-3" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : isError ? (
          <Card className="border-destructive/50">
            <CardContent className="p-6 text-center">
              <p className="text-destructive">
                Erreur lors du chargement des statistiques
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {statCards.map((card) => {
              const Icon = card.icon;
              return (
                <Card key={card.label}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <Icon className={`h-5 w-5 ${card.color}`} />
                      <span className="text-2xl font-bold text-foreground">
                        {card.value}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mt-2">{card.label}</p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Tâches par statut et par priorité */}
        {!isLoading && !isError && stats && (
          <div className="grid md:grid-cols-2 gap-4">
            {/* Par statut */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Tâches par statut</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(statusLabels).map(([key, label]) => {
                  const count = stats.tasksByStatus[key] || 0;
                  const total = stats.totalTasks || 1;
                  const percentage = Math.round((count / total) * 100);
                  return (
                    <div key={key}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-foreground">{label}</span>
                        <span className="text-muted-foreground">
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${statusColors[key] || 'bg-slate-400'}`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>

            {/* Par priorité */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Tâches par priorité</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(priorityLabels).map(([key, label]) => {
                  const count = stats.tasksByPriority[key] || 0;
                  const total = stats.totalTasks || 1;
                  const percentage = Math.round((count / total) * 100);
                  return (
                    <div key={key}>
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-foreground">{label}</span>
                        <span className="text-muted-foreground">
                          {count} ({percentage}%)
                        </span>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${priorityColors[key] || 'bg-slate-400'}`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Activités récentes */}
        {!isLoading && !isError && stats && (
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activités récentes
              </CardTitle>
            </CardHeader>
            <CardContent>
              {stats.recentActivities && stats.recentActivities.length > 0 ? (
                <div className="space-y-3 max-h-96 overflow-y-auto">
                  {stats.recentActivities.map((activity) => (
                    <div
                      key={activity.id}
                      className="flex items-start gap-3 p-3 rounded-lg bg-muted/30"
                    >
                      <Badge
                        variant="outline"
                        className={`shrink-0 mt-0.5 text-xs font-normal ${actionColors[activity.action] || 'bg-slate-100 text-slate-700 border-slate-200'}`}
                      >
                        {actionLabels[activity.action] || activity.action}
                      </Badge>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-foreground break-words">
                          {activity.description}
                        </p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xs text-muted-foreground">
                            {activity.username}
                          </span>
                          <span className="text-xs text-muted-foreground">•</span>
                          <span className="text-xs text-muted-foreground flex items-center gap-1" title={formatTimestamp(activity.timestamp)}>
                            <Clock className="h-3 w-3" />
                            {formatRelativeTime(activity.timestamp)}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground text-center py-6">
                  Aucune activité récente
                </p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </AppLayout>
  );
}
